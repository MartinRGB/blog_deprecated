(function () {
    $('.hamburger-icon').click(function () {
        $(this).toggleClass('active');
        $('.nav-container-inner').slideToggle();
        $('.container').toggleClass('active');
        $('.divider2').toggleClass('active');
    });
}.call(this));
